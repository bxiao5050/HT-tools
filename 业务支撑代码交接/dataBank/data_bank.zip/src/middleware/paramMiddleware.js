/**
 * Created by jishan.fan on 2016/7/28.
 */
"use strict";
var paramMiddleware = function(req){
    var userAccess = req.session['access'];

}