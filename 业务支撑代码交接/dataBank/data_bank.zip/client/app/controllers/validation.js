﻿'use strict';

app.controller('ValidationCtrl', function ($scope) {
    
});